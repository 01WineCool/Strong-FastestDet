import torch
import torch.nn as nn
import torch.nn as nn
import torch.nn.functional as F
import torch
from timm.models.layers import CondConv2d



class DynamicConv(nn.Module):
    def __init__(self, in_features, out_features, kernel_size=1, num_experts=2, reduction=16):
        super().__init__()
        self.routing = nn.Linear(in_features, num_experts)
        self.cond_conv = CondConv2d(in_features, out_features, kernel_size,
                                    padding=kernel_size // 2, num_experts=num_experts)

        self.se = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(out_features, out_features // reduction, 1),
            nn.ReLU(),
            nn.Conv2d(out_features // reduction, out_features, 1),
            nn.Sigmoid()
        )

    def forward(self, x):

        pooled = F.adaptive_avg_pool2d(x, 1).flatten(1)
        routing_weights = torch.sigmoid(self.routing(pooled))
        x = self.cond_conv(x, routing_weights)
        return x * self.se(x)

class Conv1x1(nn.Module):
    def __init__(self, input_channels, output_channels):
        super(Conv1x1, self).__init__()
        self.conv1x1 =  nn.Sequential(nn.Conv2d(input_channels, output_channels, 1, stride=1, padding=0, bias=False),
                                      nn.BatchNorm2d(output_channels),
                                      nn.ReLU(inplace=True)
                                     )
    
    def forward(self, x):
        return self.conv1x1(x)

class Head(nn.Module):
    def __init__(self, input_channels, output_channels):
        super(Head, self).__init__()
        self.conv5x5 = nn.Sequential(#nn.Conv2d(input_channels, input_channels, 5, 1, 2, groups = input_channels, bias = False),
            DynamicConv(input_channels, input_channels),
                                     nn.BatchNorm2d(input_channels),
                                     nn.ReLU(inplace=True),

                                     nn.Conv2d(input_channels, output_channels, 1, stride=1, padding=0, bias=False),
                                     nn.BatchNorm2d(output_channels)
                                    ) 
    
    def forward(self, x):
        return self.conv5x5(x)

#this is LSPP
class SPP(nn.Module):     #LSPP
    def __init__(self, input_channels, output_channels):
        super(SPP, self).__init__()
        self.Conv1x1 = nn.Conv2d(input_channels, output_channels, 1)
        self.base_conv = nn.Conv2d(output_channels, output_channels, 3,
                                   padding=1, groups=output_channels, bias=False)
        self.dilations = [3, 5, 7]
        self.channel_att = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(output_channels, max(4, output_channels // 16), 1),
            nn.SiLU(),
            nn.Conv2d(max(4, output_channels // 16), output_channels, 1),
            nn.Sigmoid()
        )
        self.output = nn.Sequential(
            nn.Conv2d(output_channels * 3, output_channels, 1, groups=4),
            nn.BatchNorm2d(output_channels),
            nn.SiLU()
        )
        self.shortcut = nn.Identity() if input_channels == output_channels else \
            nn.Conv2d(input_channels, output_channels, 1)

    def forward(self, x):
        residual = self.shortcut(x)
        x = self.Conv1x1(x)

        features = []
        for d in self.dilations:
            feat = F.conv2d(x, self.base_conv.weight, padding=d, dilation=d,
                            groups=self.base_conv.groups)
            feat = feat * self.channel_att(feat)
            features.append(feat)

        y = self.output(torch.cat(features, dim=1))
        return F.silu(residual + y)


class DetectHead(nn.Module):
    def __init__(self, input_channels, category_num):
        super(DetectHead, self).__init__()
        self.conv1x1 =  Conv1x1(input_channels, input_channels)

        self.obj_layers = Head(input_channels, 1)
        self.reg_layers = Head(input_channels, 4)
        self.cls_layers = Head(input_channels, category_num)

        self.sigmoid = nn.Sigmoid()
        self.softmax = nn.Softmax(dim=1)

    def forward(self, x):
        x = self.conv1x1(x)

        obj = self.sigmoid(self.obj_layers(x))
        reg = self.reg_layers(x)
        cls = self.softmax(self.cls_layers(x))

        return torch.cat((obj, reg, cls), dim =1)


# import warnings
# class SPPF(nn.Module):
#     # Spatial Pyramid Pooling - Fast (SPPF) layer for YOLOv5 by Glenn Jocher
#     def __init__(self, c1, c2, k=5):  # equivalent to SPP(k=(5, 9, 13))
#         super().__init__()
#         c_ = c1 // 2  # hidden channels
#         self.cv1 = Conv(c1, c_, 1, 1)
#         self.cv2 = Conv(c_ * 4, c2, 1, 1)
#         self.m = nn.MaxPool2d(kernel_size=k, stride=1, padding=k // 2)
#
#     def forward(self, x):
#         x = self.cv1(x)
#         with warnings.catch_warnings():
#             warnings.simplefilter('ignore')  # suppress torch 1.9.0 max_pool2d() warning
#             y1 = self.m(x)
#             y2 = self.m(y1)
#             return self.cv2(torch.cat((x, y1, y2, self.m(y2)), 1))
#
# class SimConv(nn.Module):
#     '''Normal Conv with ReLU activation'''
#     def __init__(self, in_channels, out_channels, kernel_size, stride, groups=1, bias=False):
#         super().__init__()
#         padding = kernel_size // 2
#         self.conv = nn.Conv2d(
#             in_channels,
#             out_channels,
#             kernel_size=kernel_size,
#             stride=stride,
#             padding=padding,
#             groups=groups,
#             bias=bias,
#         )
#         self.bn = nn.BatchNorm2d(out_channels)
#         self.act = nn.ReLU()
#
#     def forward(self, x):
#         return self.act(self.bn(self.conv(x)))
#
#     def forward_fuse(self, x):
#         return self.act(self.conv(x))
#
# class SimSPPF(nn.Module):
#     '''Simplified SPPF with ReLU activation'''
#     def __init__(self, in_channels, out_channels, kernel_size=5):
#         super().__init__()
#         c_ = in_channels // 2  # hidden channels
#         self.cv1 = SimConv(in_channels, c_, 1, 1)
#         self.cv2 = SimConv(c_ * 4, out_channels, 1, 1)
#         self.m = nn.MaxPool2d(kernel_size=kernel_size, stride=1, padding=kernel_size // 2)
#
#     def forward(self, x):
#         x = self.cv1(x)
#         with warnings.catch_warnings():
#             warnings.simplefilter('ignore')
#             y1 = self.m(x)
#             y2 = self.m(y1)
#             return self.cv2(torch.cat([x, y1, y2, self.m(y2)], 1))
#
#
# # without BN version
# class ASPP(nn.Module):
#     def __init__(self, in_channel=512, out_channel=256):
#         super(ASPP, self).__init__()
#         self.mean = nn.AdaptiveAvgPool2d((1, 1))  # (1,1)means ouput_dim
#         self.conv = nn.Conv2d(in_channel,out_channel, 1, 1)
#         self.atrous_block1 = nn.Conv2d(in_channel, out_channel, 1, 1)
#         self.atrous_block6 = nn.Conv2d(in_channel, out_channel, 3, 1, padding=6, dilation=6)
#         self.atrous_block12 = nn.Conv2d(in_channel, out_channel, 3, 1, padding=12, dilation=12)
#         self.atrous_block18 = nn.Conv2d(in_channel, out_channel, 3, 1, padding=18, dilation=18)
#         self.conv_1x1_output = nn.Conv2d(out_channel * 5, out_channel, 1, 1)
#
#     def forward(self, x):
#         size = x.shape[2:]
#
#         image_features = self.mean(x)
#         image_features = self.conv(image_features)
#         image_features = F.upsample(image_features, size=size, mode='bilinear')
#
#         atrous_block1 = self.atrous_block1(x)
#         atrous_block6 = self.atrous_block6(x)
#         atrous_block12 = self.atrous_block12(x)
#         atrous_block18 = self.atrous_block18(x)
#
#         net = self.conv_1x1_output(torch.cat([image_features, atrous_block1, atrous_block6,
#                                               atrous_block12, atrous_block18], dim=1))
#         return net
#
#
# class SPPCSPC(nn.Module):
#     # CSP https://github.com/WongKinYiu/CrossStagePartialNetworks
#     def __init__(self, c1, c2, n=1, shortcut=False, g=1, e=0.5, k=(5, 9, 13)):
#         super(SPPCSPC, self).__init__()
#         c_ = int(2 * c2 * e)  # hidden channels
#         self.cv1 = Conv(c1, c_, 1, 1)
#         self.cv2 = Conv(c1, c_, 1, 1)
#         self.cv3 = Conv(c_, c_, 3, 1)
#         self.cv4 = Conv(c_, c_, 1, 1)
#         self.m = nn.ModuleList([nn.MaxPool2d(kernel_size=x, stride=1, padding=x // 2) for x in k])
#         self.cv5 = Conv(4 * c_, c_, 1, 1)
#         self.cv6 = Conv(c_, c_, 3, 1)
#         self.cv7 = Conv(2 * c_, c2, 1, 1)
#
#     def forward(self, x):
#         x1 = self.cv4(self.cv3(self.cv1(x)))
#         y1 = self.cv6(self.cv5(torch.cat([x1] + [m(x1) for m in self.m], 1)))
#         y2 = self.cv2(x)
#         return self.cv7(torch.cat((y1, y2), dim=1))
#
#
# class SPPFCSPC(nn.Module):
#
#     def __init__(self, c1, c2, n=1, shortcut=False, g=1, e=0.5, k=5):
#         super(SPPFCSPC, self).__init__()
#         c_ = int(2 * c2 * e)  # hidden channels
#         self.cv1 = Conv(c1, c_, 1, 1)
#         self.cv2 = Conv(c1, c_, 1, 1)
#         self.cv3 = Conv(c_, c_, 3, 1)
#         self.cv4 = Conv(c_, c_, 1, 1)
#         self.m = nn.MaxPool2d(kernel_size=k, stride=1, padding=k // 2)
#         self.cv5 = Conv(4 * c_, c_, 1, 1)
#         self.cv6 = Conv(c_, c_, 3, 1)
#         self.cv7 = Conv(2 * c_, c2, 1, 1)
#
#     def forward(self, x):
#         x1 = self.cv4(self.cv3(self.cv1(x)))
#         x2 = self.m(x1)
#         x3 = self.m(x2)
#         y1 = self.cv6(self.cv5(torch.cat((x1, x2, x3, self.m(x3)), 1)))
#         y2 = self.cv2(x)
#         return self.cv7(torch.cat((y1, y2), dim=1))
#
#
# class SPPCSPC_group(nn.Module):
#     def __init__(self, c1, c2, n=1, shortcut=False, g=1, e=0.5, k=(5, 9, 13)):
#         super(SPPCSPC_group, self).__init__()
#         c_ = int(2 * c2 * e)  # hidden channels
#         self.cv1 = Conv(c1, c_, 1, 1, g=4)
#         self.cv2 = Conv(c1, c_, 1, 1, g=4)
#         self.cv3 = Conv(c_, c_, 3, 1, g=4)
#         self.cv4 = Conv(c_, c_, 1, 1, g=4)
#         self.m = nn.ModuleList([nn.MaxPool2d(kernel_size=x, stride=1, padding=x // 2) for x in k])
#         self.cv5 = Conv(4 * c_, c_, 1, 1, g=4)
#         self.cv6 = Conv(c_, c_, 3, 1, g=4)
#         self.cv7 = Conv(2 * c_, c2, 1, 1, g=4)
#
#     def forward(self, x):
#         x1 = self.cv4(self.cv3(self.cv1(x)))
#         y1 = self.cv6(self.cv5(torch.cat([x1] + [m(x1) for m in self.m], 1)))
#         y2 = self.cv2(x)
#         return self.cv7(torch.cat((y1, y2), dim=1))
#
#
